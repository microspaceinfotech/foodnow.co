let converter = require('./lib/code-http-converter');

module.exports = {
  getOptions: converter.getOptions,
  convert: converter.convert
};
